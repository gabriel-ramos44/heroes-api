export const jwtConstants = {
    secret: 'qvgyhj6&%%d1a1j3i5nxa8q+i!5*y3fln(j_#xpj-94x2q+zei' // usar env em prod
    //'secretKey',
  };
