import { Controller, Post, Body, Res, Get, UseGuards } from '@nestjs/common';
import { AuthService } from './auth.service';
import { LoginDto } from './dto/login.dto';
import { validate } from 'class-validator';
import { plainToClass } from 'class-transformer';
import { AuthGuard } from '@nestjs/passport';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('login')
  async login(@Res() res, @Body() loginData: LoginDto) {
    const loginDto = plainToClass(LoginDto, loginData);
    const errors = await validate(loginDto);

    if (errors.length > 0) {
      const errorMessages = errors.map(error => ({
        property: error.property,
        messages: Object.values(error.constraints)
      }));
      return res.status(400).json({ message: 'Validation Error', errors: errorMessages });
    }

    const user = await this.authService.validateUser(loginData);
    if (!user) {
      return res.status(401).json({ message: 'Invalid Credentials' });
    }

    const token = await this.authService.login(user);
    return res.status(200).json(token);
  }

}
