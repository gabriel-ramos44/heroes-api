import { Controller, Post, Body, Res } from '@nestjs/common';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { validate } from 'class-validator';
import { plainToClass } from 'class-transformer';

@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post('register')
  async create(@Res() res, @Body() userData: CreateUserDto) {
    const createUserDto = plainToClass(CreateUserDto, userData);
    const errors = await validate(createUserDto);

    if (errors.length > 0) {
      const errorMessages = errors.map(error => ({
        property: error.property,
        messages: Object.values(error.constraints)
      }));
      return res.status(400).json({ message: 'Validation Error', errors: errorMessages });
    }

    try {
      const user = await this.usersService.create(userData);
      return res.status(201).json({ message: 'User registered successfully.' });
    } catch (error) {
      return res.status(500).json({ message: 'Error registering user', error: error.message });
    }
  }

}
